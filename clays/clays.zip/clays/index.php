<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package clays
 */

get_header();
?>

	<main id="primary" class="site-main">
      <div class="speak_m_wrap">
        <div class="needs01">
          <p class="speak_s_img"><img src="<?php echo get_template_directory_uri(); ?>/img/speak_s.svg" alt="" /></p>
          <p class="needs_eng">START ON A LOW BUDGET</p>
          <p class="needs">"少額予算ではじめる！"</p>
        </div>
        <p class="needs_ttl">"中小企業向け<br />ワンストップ型Web広告運用代行"</p>
        <p class="needs_dsc">Web広告をはじめるのに必要な<br />ターゲット選定、ランディングペ<br />ージ、広告用動画、運用代行まで<br />を全てワンストップで代行いたし<br />ます。</p>
        <p class="movie_img"><img src="<?php echo get_template_directory_uri(); ?>/img/movie.svg" alt="" /></p>
		  <?php echo apply_shortcodes( '[contact-form-7 id="12" title="コンタクトフォーム small"]' ); ?>

<!--         <div class="contact_form small">
          <p>お問い合わせ</p>
          <table>
            <tr>
              <td>お名前　　<label for="" class="rqrd">必須</label></td>
              <td><input type="text" required /></td>
            </tr>
            <tr>
              <td>会社名・組織名　　<label for="">任意</label></td>
              <td><input type="text" /></td>
            </tr>
            <tr>
              <td>URL　　<label for="">任意</label></td>
              <td><input type="text" /></td>
            </tr>
            <tr>
              <td>メールアドレス　　<label for="" class="rqrd">必須</label></td>
              <td><input type="text" required /></td>
            </tr>
            <tr>
              <td>概要　　<label for="" class="rqrd">必須</label></td>
              <td><input type="text" required /></td>
            </tr>
            <tr>
              <td>お問い合わせ内容　　<label for="">任意</label></td>
              <td class="textarea"><input type="textarea" /></td>
            </tr>
            <tr>
              <td>ご予算　　<label for="">任意</label></td>
              <td><input type="text" /></td>
            </tr>
            <tr>
              <td>
                <span>
                  <label for="" class="rqrd">必須</label>
                  <input type="checkbox" required />
                  <span> プライバシーポリシーの内容を確認し同意しました。</span>
                </span>
              </td>
            </tr>
          </table>
          <p class="submit_btn">送信する</p>
        </div> -->
      </div>
      <div class="speak_l_wrap">
        <img src="<?php echo get_template_directory_uri(); ?>/img/logo_clays_m_clr.svg" alt="" class="logo_float01" />
        <img src="<?php echo get_template_directory_uri(); ?>/img/logo_clays_l_clr.svg" alt="" class="logo_float02" />
        <img src="<?php echo get_template_directory_uri(); ?>/img/logo_clays_l.svg" alt="" class="logo_float03" />
        <img src="<?php echo get_template_directory_uri(); ?>/img/logo_clays_l_clr.svg" alt="" class="logo_float04" />
        <img src="<?php echo get_template_directory_uri(); ?>/img/logo_clays_s.svg" alt="" class="logo_float05" />
        <img src="" alt="" class="logo_float01" />
        <img src="" alt="" class="logo_float01" />
        <img src="<?php echo get_template_directory_uri(); ?>/img/speak_l.svg" alt="" />
        <p class="needs02">"はじめてのWeb広告、諦めていませんか？"</p>
        <p class="needs_img"><img src="<?php echo get_template_directory_uri(); ?>/img/issues.svg" alt="" /></p>
        <p class="border fst"></p>
        <p class="border scn"></p>
        <p class="border thd"></p>
      </div>
      <div class="contact_form_wrap">
        <p class="cta_ttl">貴社のご予算に応じた最善策を<br class="sp" />ご提案いたします！</p>
        <p class="cta_dsc">
          無料相談会実施中！<br />
          まずはお気軽にお問い合せください。
        </p>
		  <?php echo apply_shortcodes( '[contact-form-7 id="13" title="コンタクトフォーム large"]' ); ?>
<!--         <div class="contact_form large">
          <p>お問い合わせ</p>
          <table>
            <tr>
              <td>お名前　　<label for="" class="rqrd">必須</label></td>
              <td><input type="text" required /></td>
            </tr>
            <tr>
              <td>会社名・組織名　　<label for="">任意</label></td>
              <td><input type="text" /></td>
            </tr>
            <tr>
              <td>URL　　<label for="">任意</label></td>
              <td><input type="text" /></td>
            </tr>
            <tr>
              <td>メールアドレス　　<label for="" class="rqrd">必須</label></td>
              <td><input type="text" required /></td>
            </tr>
            <tr>
              <td>概要　　<label for="" class="rqrd">必須</label></td>
              <td><input type="text" required /></td>
            </tr>
            <tr>
              <td>お問い合わせ内容　　<label for="">任意</label></td>
              <td class="textarea"><input type="textarea" /></td>
            </tr>
            <tr>
              <td>ご予算　　<label for="">任意</label></td>
              <td><input type="text" /></td>
            </tr>
            <tr>
              <td>
                <span>
                  <label for="" class="rqrd">必須</label>
                  <input type="checkbox" required />
                  <span> プライバシーポリシーの内容を確認し同意しました。</span>
                </span>
              </td>
            </tr>
          </table>
          <p class="submit_btn">送信する</p>
        </div> -->
        <p class="footer_logo_img"><img src="<?php echo get_template_directory_uri(); ?>/img/logo_clays_footer.svg" alt="" /></p>
      </div>



	</main><!-- #main -->

<?php
get_sidebar();
get_footer();
